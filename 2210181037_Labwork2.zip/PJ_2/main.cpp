#include <iostream>
#include <string.h>
#include <stdio.h>
#include <vector>
#include "OperationFile.h"
#include "LinkedList.h"
#include "Online.h"


using namespace std;
void save(string a,string b,string c,string d,string e){
	LinkedList LinkedList1;
	Online transaksi;
	transaksi.SaveToXML(a, b, b, d, e);
	LinkedList1 = transaksi.XMLToLinkedList();
}

void input() {
	string jenis, metode, tanggal, waktu, harga;
	cout << "Masukkan jenis: ";
	getline(cin, jenis);
	cout << "Masukkan Metode: ";
	getline(cin, metode);
	cout << "Masukkan tanggal: ";
	getline(cin, tanggal);
	cout << "Masukkan waktu : ";
	getline(cin, waktu);
	cout << "Masukkan harga: ";
	getline(cin, harga);
	save(jenis, metode, tanggal, waktu, harga);
	
}
int main(){
	cout<<"========================================================\n";
	cout<<"\t\t\tTuku bae\n";
	cout<<"========================================================\n";
	input();
}


